﻿using CalamityMod.Items.Weapons.Ranged;
using FKsCRE.Content.DeveloperItems.Weapon.Pyroblast;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria;
using CalamityMod;
using Microsoft.Xna.Framework;
using CalamityMod.Projectiles.Melee;

namespace FKsCRE.Content.DeveloperItems.Weapon.TheGoldenFire
{
    public class TheGoldenFire : ModItem, ILocalizedModType
    {
        public new string LocalizationCategory => "DeveloperItems.TheGoldenFire";
        public static readonly int OriginalUseTime = 30;

        public override void SetDefaults()
        {
            Item.damage = 60;
            Item.DamageType = DamageClass.Ranged;
            Item.useTime = Item.useAnimation = OriginalUseTime;
            Item.shoot = ModContent.ProjectileType<TheGoldenFireHoldOut>();
            Item.shootSpeed = 15f;
            Item.knockBack = 6.5f;

            Item.width = 96;
            Item.height = 42;
            Item.noMelee = true;
            Item.channel = true;
            Item.noUseGraphic = true;
            Item.useAmmo = AmmoID.Gel;
            Item.value = Item.buyPrice(0, 50, 0, 0); // 价值调整
            Item.rare = ItemRarityID.Red;
            Item.useStyle = ItemUseStyleID.Shoot;
        }
        public override void ModifyWeaponDamage(Player player, ref StatModifier damage)
        {
            //if (Main.zenithWorld)
            //醉酒世界drunkWorld
            //困难世界getGoodWorld
            //10周年世界tenthAnniversaryWorld
            //饥荒世界dontStarveWorld
            //蜜蜂世界notTheBeesWorld
            //地下世界remixWorld
            //陷阱世界noTrapsWorld
            //天顶世界zenithWorld

            // 第1阶段
            // 第2阶段
            // 第3阶段
            // 第4阶段
            // 第5阶段

            bool kingSlime = NPC.downedSlimeKing; // 史莱姆王
            bool eyeOfCthulhu = NPC.downedBoss1; // 眼睛
            bool eaterOfWorldsOrBrain = NPC.downedBoss2; // EoW BoC
            bool queenBee = NPC.downedQueenBee; // 蜂后
            bool skeletron = NPC.downedBoss3; // 骷髅王
            bool deerclops = NPC.downedDeerclops; // 独眼巨鹿
            bool wallOfFlesh = Main.hardMode; // 肉山
            bool mechanicalBosses1 = NPC.downedMechBoss1; // 毁灭者
            bool mechanicalBosses2 = NPC.downedMechBoss2; // 双子魔眼
            bool mechanicalBosses3 = NPC.downedMechBoss3; // 机械骷髅王
            bool plantera = NPC.downedPlantBoss; // 花
            bool golem = NPC.downedGolemBoss; // 石
            bool empress = NPC.downedEmpressOfLight; // 女皇
            bool fishron = NPC.downedFishron; // 公爵
            bool cultist = NPC.downedAncientCultist; // 教徒
            bool moonLord = NPC.downedMoonlord; // 月总

 
            bool dragonfolly = DownedBossSystem.downedDragonfolly; // 金龙
            bool boomerDuke = DownedBossSystem.downedBoomerDuke; // 老核弹
            bool exoMechs = DownedBossSystem.downedExoMechs; // 巨械
            bool calamitas = DownedBossSystem.downedCalamitas; // 灾厄之影
            bool calamitasClone = DownedBossSystem.downedCalamitasClone; // 至尊灾厄
            bool desertScourge = DownedBossSystem.downedDesertScourge; // 荒漠灾虫
            bool aquaticScourge = DownedBossSystem.downedAquaticScourge; // 渊海灾虫
            bool astrumAureus = DownedBossSystem.downedAstrumAureus; // 白金
            bool ceaselessVoid = DownedBossSystem.downedCeaselessVoid; // 无尽虚空
            bool signus = DownedBossSystem.downedSignus; // 西格纳斯
            bool stormWeaver = DownedBossSystem.downedStormWeaver; // 风暴编织者
            bool brimstoneElemental = DownedBossSystem.downedBrimstoneElemental; // 硫磺火元素
            bool cryogen = DownedBossSystem.downedCryogen; // 极地冰灵
            bool crabulon = DownedBossSystem.downedCrabulon; // 螃蟹
            bool guardians = DownedBossSystem.downedGuardians; // 亵渎守卫
            bool hiveMind = DownedBossSystem.downedHiveMind; // 意志
            bool perforator = DownedBossSystem.downedPerforator; // 宿主
            bool polterghast = DownedBossSystem.downedPolterghast; // 幽花
            bool slimeGod = DownedBossSystem.downedSlimeGod; // 史莱姆之神
            bool providence = DownedBossSystem.downedProvidence; // 亵渎天神
            bool devourerOfGods = DownedBossSystem.downedDoG; // 神吞
            bool yharon = DownedBossSystem.downedRavager; // 毁灭魔像
            bool astrumDeus = DownedBossSystem.downedAstrumDeus; // 星神游龙
            bool plaguebringer = DownedBossSystem.downedPlaguebringer; // 瘟疫使者歌莉娅
            bool BR = DownedBossSystem.downedBossRush; // BR


            // 这byd忍不了一点，单独列几个阴间的出来：
            // downedGSS：大沙狂鲨
            // downedCLAM：巨像蛤
            // downedCLAMHardMode：肉后巨像蛤
            // downedPlaguebringer：瘟疫使者（是boss）
            // CragmawMire：伽玛史莱姆
            // downedDreadnautilus：恐惧鹦鹉螺
            // Mauler：渊海狂鲨
            // CragmawMire：伽玛史莱姆           
        }
        public override bool CanUseItem(Player player) => player.ownedProjectileCounts[Item.shoot] == 0;

        public override bool CanConsumeAmmo(Item ammo, Player player) => player.ownedProjectileCounts[Item.shoot] != 0;

        public override void HoldItem(Player player) => player.Calamity().mouseRotationListener = true;

        public override bool Shoot(Player player, Terraria.DataStructures.EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            Projectile.NewProjectileDirect(
                source,
                player.MountedCenter,
                Vector2.Zero,
                ModContent.ProjectileType<TheGoldenFireHoldOut>(),
                Item.damage,
                Item.knockBack,
                player.whoAmI
            ).velocity = (player.Calamity().mouseWorld - player.MountedCenter).SafeNormalize(Vector2.Zero);
            return false;
        }

        public override void AddRecipes()
        {
            Recipe recipe = CreateRecipe(1);
            recipe.AddIngredient<SparkSpreader>(1);
            recipe.AddIngredient(ItemID.GoldBar, 10);
            //recipe.AddCondition(Condition.DownedMoonLord);
            recipe.AddTile(TileID.Anvils);
            recipe.Register();
        }

    }
}


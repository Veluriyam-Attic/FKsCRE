﻿//using CalamityMod.World;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using Terraria;
//using Terraria.ModLoader;

//namespace FKsCRE.Content.Arrows.AstralArrow
//{
//    public class AstralArrowPlayer : ModPlayer
//    {
//        public bool ZoneAstral; // 标志位：玩家是否在 AstralBiome 中

//        // 每帧更新
//        public override void UpdateBiomes()
//        {
//            // 在这里你需要判断玩家是否处于 AstralBiome 区域
//            ZoneAstral = ModContent.GetInstance<AstralBiome>().IsPlayerInBiome(Player); // 具体逻辑取决于 AstralBiome 的实现
//        }

//        public override void CopyClientState(ModPlayer targetCopy)
//        {
//            // 同步玩家状态
//            AstralArrowPlayer clone = targetCopy as AstralArrowPlayer;
//            clone.ZoneAstral = ZoneAstral;
//        }

//        public override void SendClientChanges(ModPlayer clientPlayer)
//        {
//            // 通知客户端更新
//            AstralArrowPlayer clone = clientPlayer as AstralArrowPlayer;
//            if (clone.ZoneAstral != ZoneAstral)
//            {
//                // 处理同步逻辑
//                ModPacket packet = Mod.GetPacket();
//                packet.Write((byte)MessageType.SyncAstralBiome);
//                packet.Write(Player.whoAmI);
//                packet.Write(ZoneAstral);
//                packet.Send();
//            }
//        }
//    }
//}
